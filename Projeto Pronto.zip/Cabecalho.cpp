#include "Cabecalho.h"

Menu::Menu()
{
    //ctor
}

void Menu::setOpcao(int opcao){
opcao1 = opcao;
}

int Menu::displayMenuPrincipal(){


    while(1){
        cout << "---------------------FLAPPY BIRD----------------------" << endl << endl << endl << endl;

        cout << "                    [1]JOGAR                         " << endl <<  endl;
        cout << "                    [2]RECORDES                       " << endl << endl;
        cout << "                    [3]SAIR                         " << endl << endl;
        cout << "Pressione ENTER apos selecionar uma opcao" << endl;

        cin >> ch;

        if (ch != 1 && ch != 2 && ch != 3){
            cout << "Opcao invalida" << endl;
            continue;

        }else if (ch == 3){
            cout << "ADEUS AMIGO, ATE BREVE!" << endl;
            return 0;
        }
        else{
        /// Escolheu JOGAR ou RECORDES
           return ch;
            break;
        }
    }

}

int Menu::displayMenuPerdeuOJogo(){

    while (1){
        system("pause");
        system ("cls");
        cout << "-----------------------FLAPPY BIRD----------------------" << endl;
        cout << "              VOCE PERDEU! JOGAR NOVAMENTE?             " << endl;
        cout << "                         [1]Sim                         " << endl;
        cout << "                         [2]Nao                         " << endl;

        cin >> ch;

        if (ch != 1 && ch != 2){
            cout << "Opcao Invalida" << endl;

        }else if (ch == 1){
            ///Cria uma nova inst�ncia do jogo para jogar novamente!!!

        }else if (ch == 2){
        /// Voltar ao menu principal

        }
        return ch;
    }
}
/*SaveRecords::SaveRecords(string name)
{
    //ctor
    playerName = name;
}*/
SaveRecords::SaveRecords()
{
    //ctor
}
/*void SaveRecords::setName(string name)
{
    playerName = name;
}*/

void SaveRecords::showRecords(){
    string record;

    ifstream records ("Recordes.txt", ios::in);

    if (!records.is_open()){
    cerr << "Erro ao abrir um arquivo de Flappy Bird" << endl;
 }else{
    getline(records, record);
    cout <<"Record: " << record << endl;
    records.close();
 }

}

void SaveRecords::HighestScore(int score){
     /// The highest score will be recorded
     string record;
     int highest;

     fstream records("Recordes.txt", ios::in);

     if (!records.is_open()){
        //cerr << "Erro ao abrir um arquivo de Flappy Bird" << endl;
     }else{

    ///Ler arquivo para saber qual � o recorde atual

        getline(records, record);

        ///Depois de ler, e armazenar na string record, transformamos a string em inteiro
        highest = stoi (record);
        records.close();//fecha o modo de abertura


        if (score > highest){
            fstream records("Recordes.txt", ios::out | ios::trunc);
            records << score << endl;
            records.close();
        }
    }
}


