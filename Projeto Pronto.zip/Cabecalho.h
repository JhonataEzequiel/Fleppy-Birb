#ifndef CABECALHO_H
#define CABECALHO_H

#include <iostream>
#include <stdio.h>
#include <windows.h>
#include <wincon.h>
#include <fstream>
#include <vector>
#include <string>
#define KEY_UP 119
#define KEY_DOWN 115

using namespace std;

class Menu
{
private:
    int opcao1;

    int opcao2;

    int opcao3;

public:
    Menu();

    int ch;

    int contador = 0;

    void setOpcao(int opcao);

    int displayMenuPrincipal();

    int displayMenuPerdeuOJogo();

    int escolha();
};

class SaveRecords
{
    private:

    protected:
        int score;
        //string playerName;

    public:
        //SaveRecords(string name);
        SaveRecords();
        //void setName(string name);

       void showRecords(); ///  This one will read the file with the records and show it when requested by user on menu
       void HighestScore(int score); ///Save records will compare the score made by the player and the records that are on the file
       void SaveFile(int score);

};

#endif // CABECALHO_H
